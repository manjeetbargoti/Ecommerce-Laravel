@extends('layouts.front.front_design')
@section('content')

@include('front.product.partials.prod_supplier')

<div class="space"></div>

    <h3 style="text-align:center;position:relative;">Link has been expired!</h3>

<div class="section"></div>



@endsection