@extends('layouts.front.front_design')
@section('content')

<div class="">
    @include('front.product.partials.prod_supplier')
</div>

@endsection