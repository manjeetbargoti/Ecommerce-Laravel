@extends('layouts.front.front_design')
@section('content')

@include('front.supplier.partials.category_list')

@endsection