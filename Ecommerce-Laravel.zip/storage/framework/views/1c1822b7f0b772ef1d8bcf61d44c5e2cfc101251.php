<?php $__env->startSection('content'); ?>

<div class="product-page-heading">
    <div class="container">
    <h2><?php echo e($pageData->name); ?></h2>
    <div class="page_content" style="padding-top: 2em;">
        <?php echo $pageData->content; ?>

    </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front.front_design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\GITHUB\Ecommerce-Laravel\resources\views/front/pages/single_page.blade.php ENDPATH**/ ?>