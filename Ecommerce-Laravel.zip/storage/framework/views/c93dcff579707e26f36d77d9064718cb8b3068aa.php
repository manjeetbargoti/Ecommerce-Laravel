<?php $__env->startSection('content'); ?>
<header class="head">
    <div class="main-bar">
        <div class="row">
            <div class="col-6">
                <h4 class="m-t-5">
                    <i class="fa fa-home"></i>
                    User Address
                </h4>
            </div>
        </div>
    </div>
</header>
<div class="outer">
    <div class="container">
        <div class="row">
            <div class="col-xl-12 m-auto">
                <div class="card">
                    <div class="card-header">Add New Address</div>
                    <div class="card-body">
                        <a href="<?php echo e(url('/admin/profile')); ?>" title="Back"><button class="btn btn-warning btn-sm"><i
                                    class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>
                        <br />
                        <br />

                        <?php if($errors->any()): ?>
                        <ul class="alert alert-danger">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php endif; ?>

                        <form action="<?php echo e(url('admin/user/address')); ?>" method="post"
                            class="form-horizontal login_validator" enctype="multipart/form-data"
                            id="form_inline_validator">
                            <?php echo csrf_field(); ?>

                            <!--  Name Input Field -->
                            <div class="form-group row">
                                <div class="col-xl-4 text-xl-right">
                                    <label for="Full Name" class="col-form-label"><?php echo e(__('Full Name *')); ?></label>
                                </div>
                                <div class="col-xl-4">
                                    <input type="text" id="FullName" name="name"
                                        class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" required
                                        value="<?php echo e(old('name')); ?>">
                                </div>
                            </div>
                            <!-- /.Name Input Field -->

                            <!-- Phone Number Input Field -->
                            <div class="form-group row">
                                <div class="col-xl-4 text-xl-right">
                                    <label for="Phone" class="col-form-label"><?php echo e(__('Phone *')); ?></label>
                                </div>
                                <div class="col-xl-4">
                                    <input type="tel" id="PhoneNumber" name="phone"
                                        class="form-control <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" required
                                        value="<?php echo e(old('phone')); ?>">
                                </div>
                            </div>
                            <!-- Phone Number Input Field -->

                            <!-- Address Input Field -->
                            <div class="form-group row">
                                <div class="col-xl-4 text-xl-right">
                                    <label for="Full Address" class="col-form-label"><?php echo e(__('Full Address *')); ?></label>
                                </div>
                                <div class="col-xl-4">
                                    <textarea name="address1" id="Address1" cols="30" rows="3"
                                        class="form-control <?php if ($errors->has('address1')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('address1'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" required
                                        value="<?php echo e(old('address1')); ?>"></textarea>
                                </div>
                            </div>
                            <!-- /.Address Input Field -->

                            <!-- Country Input Field -->
                            <div class="form-group row">
                                <div class="col-xl-4 text-xl-right">
                                    <label for="Country" class="col-form-label"><?php echo e(__('Country *')); ?></label>
                                </div>
                                <div class="col-xl-4">
                                    <select name="country" id="Country"
                                        class="form-control <?php if ($errors->has('country')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('country'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                                        <option value="" selected> -- Select Country -- </option>
                                        <?php $__currentLoopData = \App\Country::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($count->iso3); ?>"> <?php echo e($count->name); ?> </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <!-- /.Country Input Field -->

                            <!-- State Input Field -->
                            <div class="form-group row">
                                <div class="col-xl-4 text-xl-right">
                                    <label for="State" class="col-form-label"><?php echo e(__('State *')); ?></label>
                                </div>
                                <div class="col-xl-4">
                                    <input type="text" id="state" name="state"
                                        class="form-control <?php if ($errors->has('state')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('state'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" required
                                        value="<?php echo e(old('state')); ?>">
                                </div>
                            </div>
                            <!-- /.State Input Field -->

                            <!-- City Input Field -->
                            <div class="form-group row">
                                <div class="col-xl-4 text-xl-right">
                                    <label for="City" class="col-form-label"><?php echo e(__('City *')); ?></label>
                                </div>
                                <div class="col-xl-4">
                                    <input type="text" id="city" name="city"
                                        class="form-control <?php if ($errors->has('city')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('city'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" required
                                        value="<?php echo e(old('city')); ?>">
                                </div>
                            </div>
                            <!-- /.City Input Field -->

                            <!-- Zipcode Input Field -->
                            <div class="form-group row">
                                <div class="col-xl-4 text-xl-right">
                                    <label for="Zipcode" class="col-form-label"><?php echo e(__('Zipcode/P.O.Box *')); ?></label>
                                </div>
                                <div class="col-xl-4">
                                    <input type="text" id="zipcode" name="zipcode"
                                        class="form-control <?php if ($errors->has('zipcode')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('zipcode'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" required
                                        value="<?php echo e(old('zipcode')); ?>">
                                </div>
                            </div>
                            <!-- /.City Input Field -->

                            <div class="form-actions form-group row">
                                <div class="col-xl-4 m-auto">
                                    <input type="reset" value="Reset" class="btn btn-warning pull-left">
                                    <input type="submit" value="Create User" class="btn btn-primary pull-right">
                                </div>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel.panel_design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\GITHUB\Ecommerce-Laravel\resources\views/admin/user-address/create.blade.php ENDPATH**/ ?>