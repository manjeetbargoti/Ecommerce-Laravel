<!-- Navigation -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top menubar-top">
    <div class="container">
        <a class="navbar-brand" href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset(config('app.logo'))); ?>" width="60px"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive"
            aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('/contact')); ?>">CONTACT</a>
                </li>
                <?php if(Route::has('login')): ?>
                <?php if(auth()->guard()->check()): ?>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">ACCOUNT</a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown"
                        style="top: 0em;left: 2em;background: rgba(255,255,255,0.05);">
                        <a class="dropdown-item" href="<?php echo e(url('/admin/profile')); ?>"><i class="fa fa-user"></i>
                            Profile</a>
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();"><i
                                class="fa fa-sign-out"></i>
                            <?php echo e(__('Logout')); ?></a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </li>
                <?php else: ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('login')); ?>">SIGN IN</a>
                </li>
                <?php endif; ?>
                <?php endif; ?>
                <li class="nav-item">
                    <a class="nav-link d-lg-none d-md-none d-sm-block d-xs-block" href="#">ABOUT</a>
                </li>
            </ul>
        </div>
    </div>
</nav><?php /**PATH D:\GITHUB\Ecommerce-Laravel\resources\views/layouts/front/header/front_header.blade.php ENDPATH**/ ?>