<?php $__env->startSection('content'); ?>
<div id="particles-js"></div>
<div class="product-page-heading">
    <div class="menu-destination-prehome">
        <ul class="list-unstyled text-center">
            <li>
                <div style="display: block;"><a>WELCOME</a></div>
            </li>
        </ul>
    </div>
</div>
<div class="container inquireform">
    <div class="col-lg-3 col-md-3 d-none d-md-block d-lg-block"></div>
    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
        <!-- Default form contact -->
        <form action="<?php echo e(route('login')); ?>" id="login_validator" method="post" class="login_validator p-4">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="email" class="col-form-label"> <?php echo e(__('E-Mail Address')); ?></label>
                <input id="email" type="email" name="email"
                    class="form-control  form-control-md <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="email"
                    name="username" value="<?php echo e(old('email')); ?>" placeholder="E-mail" required autocomplete="email"
                    autofocus>
                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
            <div class="form-group">
                <label for="password" class="col-form-label"><?php echo e(__('Password')); ?></label>
                <input id="password" type="password"
                    class="form-control form-control-md <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="password"
                    name="password" required autocomplete="current-password" placeholder="Password">
                <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
            </div>
            <div class="form-group">
                <div class="row">
                    <div class="col-6">
                        <label class="custom-control custom-checkbox">
                            <input type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>

                                class="form-check-input">
                            <span class="custom-control-indicator"></span>
                            <a class="custom-control-description"><?php echo e(__('Keep me logged in')); ?></a>
                        </label>
                    </div>
                    <div class="col-6 text-right forgot_pwd">
                        <?php if(Route::has('password.request')): ?>
                        <a href="<?php echo e(route('password.request')); ?>"
                            class="custom-control-description forgottxt_clr text-success" style="color: #67d5ae !important;"><?php echo e(__('Forgot Password?')); ?></a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <div class="col-lg-12">
                        <input type="submit" value="<?php echo e(__('Login')); ?>" class="btn btn-info btn-block login_button">
                    </div>
                </div>
            </div>
            <div class="form-group">
                <label class="col-form-label"> </label>
                <a href="<?php echo e(route('register')); ?>" class=""
                    style="color:#67d5ae;font-size:18px;font-weight:bold;"><b>CREATE AN ACCOUNT</b></a>
            </div>
        </form>
    </div>
    <div class="col-lg-3 col-md-3 d-none d-md-block d-lg-block"></div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front.front_design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\GITHUB\Ecommerce-Laravel\resources\views/auth/login.blade.php ENDPATH**/ ?>