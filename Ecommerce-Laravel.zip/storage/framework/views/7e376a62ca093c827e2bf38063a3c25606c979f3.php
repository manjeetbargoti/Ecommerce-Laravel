<?php $__env->startSection('content'); ?>

<div id="particles-js"></div>
<div class="" style="position: relative;">
    <div class="product-page-heading ">
        <div class="menu-destination-prehome">
            <ul class="list-unstyled text-center product-supplier">
                <li class="active">
                    <div style="display: block;"><a class="" href="<?php echo e(url('/product/categories')); ?>">PRODUCTS</a></div>
                </li>
                <li class="">
                    <div style="display: block;"><a class="" href="<?php echo e(url('/supplier/categories')); ?>">SUPPLIERS</a>
                    </div>
                </li>
            </ul>
        </div>
    </div>

    <div class="product-page-content">
        <div class="menu-destination-prehome">
            <ul class="list-unstyled text-center">
                <?php $__currentLoopData = $productcategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pcat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="<?php echo e((request()->is('category/'.$pcat->name)) ? 'active':''); ?>">
                    <span style="display: block;"><a class=""
                            href="<?php echo e(url('/category/'.$pcat->name.'/products/')); ?>"><?php echo e($pcat->name); ?></a></span>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <div class="menu-destination-prehome" style="padding-top: 7em;">
            <ul class="list-unstyled text-center">
                <li class="">
                    <span style="display: block;"><a class="" href="<?php echo e(url('/vvv-lux/products/')); ?>"
                            style="font-size: 3em !important;">VVV LUXURY</a></span>
                </li>
            </ul>
        </div>
        <div class="space2"></div>
    </div>
</div>


<div class="space"></div>
<!-- hero area -->
<section class="section grey-bg">
    <div class="container">
        <div class="row">
            <!-- Page Content -->
            <div class="col-lg-3 mb-5">
                <h2 class="my-4">Product Categories</h2>
                <div class="list-group">
                    <?php $__currentLoopData = $productcategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pcat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(url('/category/'.$pcat->name.'/products/')); ?>"
                        class="list-group-item green-txt gry-bg"><?php echo e($pcat->name); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <!-- /.col-lg-3 -->
            <div class="col-lg-9 all-products">
                <div class="row">

                    <?php if($products->count() == 0): ?>
                    <p style="margin: auto;padding-top: 6rem;">Sorry! We have no product in this category.</p>
                    <?php else: ?>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6 mb-4" id="watch1">
                        <div class="card h-100">
                            <a href="<?php echo e(url('/category/'.$prod->product_category.'/product/'.$prod->id)); ?>"><img
                                    class="card-img-top <?php if($prod->is_premium == 1): ?> blur-img <?php endif; ?>"
                                    src="<?php echo e(asset('images/watch1.png')); ?>" alt=""></a>
                            <div class="card-body">
                                <h5><a href="<?php echo e(url('/category/'.$prod->product_category.'/product/'.$prod->id)); ?>"
                                        class="text-white"><?php echo e($prod->product_name); ?></a></h5>
                                <p class="card-text mt-2"><?php echo e(str_limit($prod->product_description, $limit=100)); ?></p>
                                <h4 class="card-title">
                                <?php if(Auth::check()): ?>
                                    <?php if($prod->is_premium == 1): ?>
                                    <a href="" class="green-txt" data-toggle="modal"
                                        data-target="#Product<?php echo e($prod->id); ?>">Get
                                        Inquired</a>
                                    <?php elseif($prod->is_premium == 0): ?>
                                    <a href="<?php echo e(url('/category/'.$prod->product_category.'/product/'.$prod->id)); ?>"
                                        class="green-txt">More Info</a>
                                    <?php endif; ?>
                                <?php else: ?>
                                <a href="<?php echo e(route('login')); ?>" class="green-txt">Get
                                        Inquired</a>
                                <?php endif; ?>
                                </h4>
                            </div>
                            <!-- <div class="card-footer gry-bg">
                                    <small class="text-muted green-txt">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
                                </div> -->
                        </div>
                    </div>

                    <!-- Modal -->
                    <div class="modal fade" id="Product<?php echo e($prod->id); ?>" tabindex="-1" role="dialog"
                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel"><?php echo e($prod->product_name); ?></h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <form action="<?php echo e(url('/category/'.$pcat->name.'/products/')); ?>" method="POST"
                                        class="EnquiryForm">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group">
                                            <input type="text" name="name" id="FullName" class="form-control mb-2"
                                                placeholder="Full Name" required>
                                        </div>
                                        <div class="form-group">
                                            <input type="email" name="email" id="EmailAddress" class="form-control mb-2"
                                                placeholder="Email Address" required>
                                        </div>
                                        <div class="form-group">
                                            <input type="tel" name="phone" id="PhoneNumber" class="form-control mb-2"
                                                placeholder="Phone number" required>
                                        </div>
                                        <div class="form-group d-none">
                                            <input type="text" name="product_id" id="ProductId"
                                                class="form-control mb-2" placeholder="Product ID"
                                                value="<?php echo e($prod->id); ?>">
                                        </div>
                                        <div class="form-group d-none">
                                            <input type="text" name="product_type" id="ProductType"
                                                class="form-control mb-2" placeholder="Product Type"
                                                value="<?php echo e($prod->is_premium); ?>">
                                        </div>
                                        <div class="form-group">
                                            <textarea name="location" id="Location" cols="30" rows="2"
                                                class="form-control" placeholder="Location" required></textarea>
                                        </div>
                                        <div class="form-group">
                                            <textarea name="query_message" id="QueryMessage" cols="30" rows="5"
                                                class="form-control" placeholder="Query..." required></textarea>
                                        </div>
                                        <div class="form-group">
                                            <input type="checkbox" name="terms" id="Terms" class="mb-2" value="1"
                                                required>
                                            I accept <a href="#">Terms and Conditions</a>.
                                        </div>
                                        <div class="form-group">
                                            <button type="reset" class="btn btn-warning"
                                                data-dismiss="modal">Reset</button>
                                            <button type="submit" class="btn btn-primary pull-right">Submit
                                                Query</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <!-- <h3 class="m-auto">Please <a href="<?php echo e(route('login')); ?>" style="color: #67d5ae;font-size:20px !important;">Login/Register</a> to check our products.</h3> -->

                </div>
                <!-- /.row -->
            </div>
            <!-- /.col-lg-9 -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container -->
</section><!-- header close -->
<div class="section"></div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front.front_design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\GITHUB\Ecommerce-Laravel\resources\views/front/product/vvv_products.blade.php ENDPATH**/ ?>