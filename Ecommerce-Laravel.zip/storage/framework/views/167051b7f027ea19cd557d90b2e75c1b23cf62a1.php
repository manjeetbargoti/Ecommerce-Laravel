<div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
    <label for="Name" class="control-label"></label>
    <input type="text" name="name" id="Name" class="form-control" value="<?php echo e(isset($permission->name) ? $permission->name : ''); ?>" required>
    <?php echo $errors->first('name', '<p class="help-block">:message</p>'); ?>

</div>


<div class="form-group">
    <input class="btn btn-primary" type="submit" value="<?php echo e($formMode === 'edit' ? 'Update' : 'Create'); ?>">
</div>
<?php /**PATH D:\GITHUB\Ecommerce-Laravel\resources\views/admin/permission/form.blade.php ENDPATH**/ ?>