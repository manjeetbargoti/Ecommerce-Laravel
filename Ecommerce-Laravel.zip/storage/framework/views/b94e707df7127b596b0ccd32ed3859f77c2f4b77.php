<?php $__env->startSection('content'); ?>
<header class="head">
    <div class="main-bar">
        <div class="row">
            <div class="col-6">
                <h4 class="m-t-5">
                    <i class="fa fa-home"></i>
                    Profile
                </h4>
            </div>
        </div>
    </div>
</header>
<div class="outer">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Edit Business info</div>
                    <div class="card-body">

                        <a href="<?php echo e(url('/admin/profile')); ?>" title="Back"><button class="btn btn-warning btn-sm"><i
                                    class="fa fa-arrow-left" aria-hidden="true"></i>
                                Back</button></a>
                        <form class="form-horizontal login_validator" id="tryitForm"
                            action="<?php echo e(url('/supplier-info/'.$sdata->id.'/edit')); ?>" method="post">

                            <?php echo e(csrf_field()); ?>

                            <div class="row">
                                <div class="col-12">
                                <div class="form-group row m-t-25">
                                    <div class="col-lg-3 text-lg-right">
                                        <label for="business name" class="col-form-label">Business Name *</label>
                                    </div>
                                    <div class="col-xl-6 col-lg-8">
                                        <div class="input-group">
                                            <span class="input-group-addon"> <i class="fa fa-user text-primary"></i>
                                            </span>
                                            <input readonly type="text" name="business_name" id="business_name"
                                                class="form-control" value="<?php echo e($sdata->business_name); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group row m-t-25">
                                    <div class="col-lg-3 text-lg-right">
                                        <label for="License Number" class="col-form-label">License Number *</label>
                                    </div>
                                    <div class="col-xl-6 col-lg-8">
                                        <div class="input-group">
                                            <span class="input-group-addon"> <i class="fa fa-user text-primary"></i>
                                            </span>
                                            <input type="text" name="license_number" id="license_number" class="form-control"
                                                value="<?php echo e($sdata->license_number); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group row m-t-25">
                                    <div class="col-lg-3 text-lg-right">
                                        <label for="Website" class="col-form-label">Website *</label>
                                    </div>
                                    <div class="col-xl-6 col-lg-8">
                                        <div class="input-group">
                                            <span class="input-group-addon"> <i class="fa fa-user text-primary"></i>
                                            </span>
                                            <input type="text" name="website" id="website" class="form-control"
                                                value="<?php echo e($sdata->website); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-lg-3 text-lg-right">
                                        <label for="Country" class="col-form-label">Country *</label>
                                    </div>
                                    <div class="col-xl-6 col-lg-8">
                                        <div class="input-group">
                                            <span class="input-group-addon"><i
                                                    class="fa fa-globe text-primary"></i></span>
                                            <select class="form-control" name="country" id="country">
                                                <option value="">-- Select Country --</option>
                                                <?php $__currentLoopData = \App\Country::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cont): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($cont->iso3); ?>" <?php if($cont->iso3 == $sdata->country): ?> selected <?php endif; ?>><?php echo e($cont->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-lg-3 text-lg-right">
                                        <label for="State" class="col-form-label">State
                                            *</label>
                                    </div>
                                    <div class="col-xl-6 col-lg-8">
                                        <div class="input-group">
                                            <span class="input-group-addon"><i
                                                    class="fa fa-globe text-primary"></i></span>
                                            <input type="text" placeholder=" " id="state" name="state"
                                                class="form-control" value="<?php echo e($sdata->state); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-lg-3 text-lg-right">
                                        <label for="City" class="col-form-label">City
                                            *</label>
                                    </div>
                                    <div class="col-xl-6 col-lg-8">
                                        <div class="input-group">
                                            <span class="input-group-addon"><i
                                                    class="fa fa-globe text-primary"></i></span>
                                            <input type="text" placeholder=" " id="city" name="city"
                                                class="form-control" value="<?php echo e($sdata->city); ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <div class="col-lg-6 m-auto">
                                        <button class="btn btn-warning" type="reset" id="clear">
                                            <i class="fa fa-refresh"></i>
                                            Reset
                                        </button>
                                        <button class="btn btn-primary pull-right" type="submit">
                                            <i class="fa fa-user"></i>
                                            Update
                                        </button>
                                    </div>
                                </div>
                            </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel.panel_design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\GITHUB\Ecommerce-Laravel\resources\views/admin/profile/edit-supplier-info.blade.php ENDPATH**/ ?>