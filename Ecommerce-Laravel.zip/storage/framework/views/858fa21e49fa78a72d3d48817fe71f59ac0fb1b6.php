<?php $__env->startSection('content'); ?>
<header class="head">
    <div class="main-bar">
        <div class="row">
            <div class="col-6">
                <h4 class="m-t-5">
                    <i class="fa fa-home"></i>
                    Users
                </h4>
            </div>
        </div>
    </div>
</header>
<div class="outer">
    <div class="container">
        <div class="row">
            <!-- User infromation -->
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header"><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?>

                        (<?php echo e(implode(', ', $user->getRoleNames()->toArray())); ?>)</div>
                    <div class="card-body">

                        <a href="<?php echo e(url('/admin/user')); ?>" title="Back"><button class="btn btn-warning btn-sm"><i
                                    class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>
                        <a href="<?php echo e(url('/admin/user/' . $user->id . '/edit')); ?>" title="Edit user"><button
                                class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                                Edit</button></a>
                        <form method="POST" action="<?php echo e(url('/admin/user' . '/' . $user->id)); ?>" accept-charset="UTF-8"
                            style="display:inline">
                            <?php echo e(method_field('DELETE')); ?>

                            <?php echo e(csrf_field()); ?>

                            <button type="submit" class="btn btn-danger btn-sm" title="Delete User"
                                onclick="return confirm('Confirm delete?')"><i class="fa fa-trash-o"
                                    aria-hidden="true"></i> </button>
                        </form>
                        <br />
                        <br />

                        <div class="table-responsive">
                            <table class="table table-borderless">
                                <tbody>
                                    <div class="m-auto" style="padding: 0.2em 0;">
                                        <?php if(!empty($user->image)): ?><img
                                            src="<?php echo e(url('/images/user/large/'.$user->image)); ?>" width="100"
                                            class="img-responsive img-circle"
                                            alt="<?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?>"><?php else: ?>
                                        <img src="<?php echo e(url('/images/user/user.png')); ?>" width="100"
                                            class="img-responsive img-circle"
                                            alt="<?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?>"><?php endif; ?>

                                    </div>
                                    <tr>
                                        <th>ID</th>
                                        <td><?php echo e($user->id); ?></td>
                                    </tr>
                                    <tr>
                                        <th> Name </th>
                                        <td><?php echo e($user->title); ?> <?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?>

                                            (<?php echo e($user->username); ?>)</td>
                                    </tr>
                                    <tr>
                                        <th> Phone </th>
                                        <td> <?php echo e($user->phone); ?> </td>
                                    </tr>
                                    <tr>
                                        <th> Email </th>
                                        <td> <?php echo e($user->email); ?> </td>
                                    </tr>
                                    <tr>
                                        <th> Role </th>
                                        <td> <?php echo e(implode(', ', $user->getRoleNames()->toArray())); ?> </td>
                                    </tr>

                                    <tr>
                                        <th> Status </th>
                                        <td><?php if($user->status == 1): ?> <label
                                                class="badge badge-success badge-lg">Enable</label><?php elseif($user->status
                                            == 0): ?><label class="badge badge-danger badge-lg">Disable</label> <?php endif; ?> </td>
                                    </tr>
                                    <tr>
                                        <th> Country </th>
                                        <td><?php $__currentLoopData = \App\Country::where('iso3',$user->country)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cont): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($cont->name); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                                    </tr>
                                    <tr>
                                        <th> Created on </th>
                                        <td> <?php echo e(date('d M, Y (h:i:s A)', strtotime($user->created_at))); ?> </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
            <!-- /. User information -->

            <?php if($roleName == 'Supplier' || $roleName == 'Seller'): ?>
            <!-- User infromation -->
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">Business info</div>
                    <div class="card-body">
                        <br>
                        <br>
                        <div class="table-responsive">
                            <table class="table table-borderless">
                                <tbody>
                                    <tr>
                                        <th>Business Name</th>
                                        <td><?php if(!empty($supplierData->business_name)): ?> <?php echo e($supplierData->business_name); ?>

                                            <?php endif; ?></td>
                                    </tr>
                                    <tr>
                                        <th> Category </th>
                                        <td><?php if(!empty($supplierData->category)): ?> <?php echo e($supplierData->category); ?>

                                            <?php endif; ?></td>
                                    </tr>
                                    <tr>
                                        <th> License Number </th>
                                        <td> <?php if(!empty($supplierData->license_number)): ?>
                                            <?php echo e($supplierData->license_number); ?>

                                            <?php endif; ?> </td>
                                    </tr>
                                    <tr>
                                        <th> Website </th>
                                        <td> <?php if(!empty($supplierData->website)): ?> <?php echo e($supplierData->website); ?>

                                            <?php endif; ?> </td>
                                    </tr>
                                    <tr>
                                        <th> Country </th>
                                        <td><?php $__currentLoopData = \App\Country::where('iso3',$supplierData->country)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cont): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo e($cont->name); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                                    </tr>
                                    <tr>
                                        <th> State </th>
                                        <td><?php if(!empty($supplierData->state)): ?> <?php echo e($supplierData->state); ?>

                                            <?php endif; ?></td>
                                    </tr>
                                    <tr>
                                        <th> City </th>
                                        <td><?php if(!empty($supplierData->city)): ?> <?php echo e($supplierData->city); ?>

                                            <?php endif; ?></td>
                                    </tr>
                                    <tr>
                                        <th> Created on </th>
                                        <td> <?php echo e(date('d M, Y (h:i:s A)', strtotime($supplierData->created_at))); ?> </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
            <!-- /. Supplier Business -->
            <?php endif; ?>

            <!-- User Order info -->
            <div class="col-md-12" style="padding-top: 2em;">
                <div class="card">
                    <div class="card-header"><u><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?>

                            (<?php echo e(implode(', ', $user->getRoleNames()->toArray())); ?>)</u></div>
                    <div class="card-body">

                        <a href="<?php echo e(url('/admin/user')); ?>" title="Back"><button class="btn btn-warning btn-sm"><i
                                    class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>
                        <a href="<?php echo e(url('/admin/user/' . $user->id . '/edit')); ?>" title="Edit user"><button
                                class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                                Edit</button></a>


                        <div class="table-responsive">

                        </div>

                    </div>
                </div>
            </div>
            <!-- /. User Order info -->
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel.panel_design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\GITHUB\Ecommerce-Laravel\resources\views/admin/user/show.blade.php ENDPATH**/ ?>