<html>

<head>
    <title>Contact Query | VVV Luxury</title>
</head>

<body>
    <table>
        <tr>
            <td>Hi Team,</td>
        </tr>
        <tr>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>Contact us Query form VVV Luxury website.</td>
        </tr>
        <tr>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>Name:</td>
            <td><?php echo e($name); ?></td>
        </tr>
        <tr>
            <td>Email:</td>
            <td><?php echo e($email); ?></td>
        </tr>
        <tr>
            <td>Phone:</td>
            <td><?php echo e($phone); ?></td>
        </tr>
        <tr>
            <td>Message:</td>
            <td><?php echo e($query_message); ?></td>
        </tr>
        <tr>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>Thanks & Regards,</td>
        </tr>
        <tr>
            <td><?php echo e($name); ?></td>
        </tr>
    </table>
</body>

</html><?php /**PATH D:\GITHUB\Ecommerce-Laravel\resources\views/emails/contact_email.blade.php ENDPATH**/ ?>