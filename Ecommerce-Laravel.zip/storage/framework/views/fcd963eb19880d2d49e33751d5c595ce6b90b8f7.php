<?php $__env->startSection('content'); ?>
<header class="head">
    <div class="main-bar">
        <div class="row">
            <div class="col-6">
                <h4 class="m-t-5">
                    <i class="fa fa-home"></i>
                    Products
                </h4>
            </div>
        </div>
    </div>
</header>
<div class="outer">
    <div class="container">
        <div class="row">
            <div class="col-md-9 m-auto">
                <div class="card">
                    <div class="card-header">Product <?php echo e($product->id); ?></div>
                    <div class="card-body">

                        <a href="<?php echo e(url('/admin/product')); ?>" title="Back"><button class="btn btn-warning btn-sm"><i
                                    class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>
                        <a href="<?php echo e(url('/admin/product/' . $product->id . '/edit')); ?>" title="Edit Product"><button
                                class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>
                                Edit</button></a>

                        <form method="POST" action="<?php echo e(url('admin/product' . '/' . $product->id)); ?>"
                            accept-charset="UTF-8" style="display:inline">
                            <?php echo e(method_field('DELETE')); ?>

                            <?php echo e(csrf_field()); ?>

                            <button type="submit" class="btn btn-danger btn-sm" title="Delete Product"
                                onclick="return confirm(&quot;Confirm delete?&quot;)"><i class="fa fa-trash-o"
                                    aria-hidden="true"></i> Delete</button>
                        </form>
                        <br />
                        <br />

                        <div class="table-responsive">
                            <table class="table table-hover">
                                <tbody>
                                    <tr>
                                        <th>ID</th>
                                        <td><?php echo e($product->id); ?></td>
                                    </tr>
                                    <tr>
                                        <th> Product Name </th>
                                        <td> <?php echo e($product->product_name); ?> </td>
                                    </tr>
                                    <tr>
                                        <th> Product Category </th>
                                        <td> <?php echo e($product->product_category); ?> </td>
                                    </tr>
                                    <tr>
                                        <th> Vendor </th>
                                        <td> <?php echo e($product->vendor); ?> </td>
                                    </tr>
                                    <tr>
                                        <th> Quantity </th>
                                        <td> <?php echo e($product->quantity); ?> </td>
                                    </tr>
                                    <tr>
                                        <th> Initial Stock </th>
                                        <td> <?php echo e($product->initial_stock); ?> </td>
                                    </tr>
                                    <tr>
                                        <th> Current Stock </th>
                                        <td> <?php echo e($product->current_stock); ?> </td>
                                    </tr>
                                    <tr>
                                        <th> Buying Price </th>
                                        <td> <?php echo e($product->buying_price); ?> </td>
                                    </tr>
                                    <tr>
                                        <th> Selling Price </th>
                                        <td> <?php echo e($product->selling_price); ?> </td>
                                    </tr>
                                    <tr>
                                        <th> Add By </th>
                                        <td> <?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?> </td>
                                    </tr>
                                    <tr>
                                        <th> Status </th>
                                        <td> <?php if($product->status == 1): ?> <label
                                                class="badge badge-success badge-lg badge-pill">Enable</label>
                                            <?php elseif($product->status == 0): ?> <label
                                                class="badge badge-danger badge-lg badge-pill">Disable</label> <?php endif; ?> </td>
                                    </tr>
                                    <tr>
                                        <th> Premium </th>
                                        <td> <?php if($product->is_premium == 1): ?> <label
                                                class="badge badge-success badge-lg badge-pill">Yes</label>
                                            <?php elseif($product->is_premium == 0): ?> <label
                                                class="badge badge-danger badge-lg badge-pill">No</label> <?php endif; ?> </td>
                                    </tr>
                                    <tr>
                                        <th> Product Description </th>
                                        <td> <?php echo e($product->product_description); ?> </td>
                                    </tr>
                                    <tr>
                                        <th> Created on </th>
                                        <td> <?php echo e(date('d M, Y (h:i:s A)', strtotime($product->created_at))); ?> </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel.panel_design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\GITHUB\Ecommerce-Laravel\resources\views/admin/products/show.blade.php ENDPATH**/ ?>