<?php $__env->startSection('content'); ?>
<header class="head">
    <div class="main-bar">
        <div class="row">
            <div class="col-6">
                <h4 class="m-t-5">
                    <i class="fa fa-home"></i>
                    Products
                </h4>
            </div>
        </div>
    </div>
</header>
<div class="outer">
    <div class="container">
        <div class="row">
            <div class="col-md-9 m-auto">
                <div class="card">
                    <div class="card-header">Edit Product #<?php echo e($product->id); ?> (<?php echo e($product->product_name); ?>)</div>
                    <div class="card-body">
                        <a href="<?php echo e(url('/admin/product')); ?>" title="Back"><button class="btn btn-warning btn-sm"><i
                                    class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>
                        <br />
                        <br />

                        <?php if($errors->any()): ?>
                        <ul class="alert alert-danger">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php endif; ?>

                        <form method="POST" action="<?php echo e(url('/admin/product/' . $product->id)); ?>" method="POST"
                            accept-charset="UTF-8" class="form-horizontal" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>


                            <input name="_method" type="hidden" value="PATCH">
                            <div class="form-group row">
                                <div class="col-sm-6">
                                    <label for="product_category" class="control-label"><?php echo e('Product Category'); ?></label>
                                    <select name="product_category" class="form-control" id="product_category">
                                        <option value=""> -- Select Category -- </option>
                                        <?php $__currentLoopData = $productCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pcat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($pcat->name); ?>" <?php if($product->product_category == $pcat->name): ?>
                                            selected <?php endif; ?>><?php echo e($pcat->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php echo $errors->first('product_category', '<p class="help-block">:message</p>'); ?>

                                </div>

                                <div class="col-sm-6 col-12">
                                    <label for="product_name" class="control-label"><?php echo e('Product Name'); ?></label>
                                    <input class="form-control" name="product_name" type="text" id="product_name"
                                        value="<?php echo e(isset($product->product_name) ? $product->product_name : ''); ?>">
                                    <?php echo $errors->first('product_name', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-sm-6 col-12">
                                    <label for="product_slug" class="control-label"><?php echo e('Product Url'); ?></label>
                                    <input class="form-control" name="product_slug" type="text" id="slug"
                                        value="<?php echo e(isset($product->product_slug) ? $product->product_slug : ''); ?>">
                                    <?php echo $errors->first('product_slug', '<p class="help-block">:message</p>'); ?>

                                </div>

                                <div class="col-sm-6">
                                    <label for="Vendor" class="control-label"><?php echo e('Vendor'); ?></label>
                                    <select name="vendor" class="form-control" id="vendor">
                                        <option value=""> -- Select Vendor -- </option>
                                        <?php $__currentLoopData = $productVendor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pvend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($pvend->name); ?>" <?php if($product->vendor == $pvend->name): ?>
                                            selected
                                            <?php endif; ?>><?php echo e($pvend->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php echo $errors->first('vendor', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-sm-4 col-12">
                                    <label for="Quantity" class="control-label"><?php echo e('Quantity'); ?></label>
                                    <input class="form-control" name="quantity" type="text" id="quantity"
                                        value="<?php echo e(isset($product->quantity) ? $product->quantity : ''); ?>">
                                    <?php echo $errors->first('quantity', '<p class="help-block">:message</p>'); ?>

                                </div>

                                <div class="col-sm-4 col-12">
                                    <label for="Initial Stock" class="control-label"><?php echo e('Initial Stock'); ?></label>
                                    <input class="form-control" name="initial_stock" type="text" id="initial_stock"
                                        value="<?php echo e(isset($product->initial_stock) ? $product->initial_stock : ''); ?>">
                                    <?php echo $errors->first('initial_stock', '<p class="help-block">:message</p>'); ?>

                                </div>

                                <div class="col-sm-4 col-12">
                                    <label for="Current Stock" class="control-label"><?php echo e('Current Stock'); ?></label>
                                    <input class="form-control" name="current_stock" type="text" id="current_stock"
                                        value="<?php echo e(isset($product->current_stock) ? $product->current_stock : ''); ?>">
                                    <?php echo $errors->first('current_stock', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-sm-4 col-12">
                                    <label for="Buying Price" class="control-label"><?php echo e('Buying Price'); ?></label>
                                    <input class="form-control" name="buying_price" type="text" id="buying_price"
                                        value="<?php echo e(isset($product->buying_price) ? $product->buying_price : ''); ?>">
                                    <?php echo $errors->first('buying_price', '<p class="help-block">:message</p>'); ?>

                                </div>

                                <div class="col-sm-4 col-12">
                                    <label for="Selling Price" class="control-label"><?php echo e('Selling Price'); ?></label>
                                    <input class="form-control" name="selling_price" type="text" id="selling_price"
                                        value="<?php echo e(isset($product->selling_price) ? $product->selling_price : ''); ?>">
                                    <?php echo $errors->first('selling_price', '<p class="help-block">:message</p>'); ?>

                                </div>

                                <div class="col-sm-4 col-12">
                                    <label for="Product Status" class="control-label"><?php echo e('Product Status'); ?></label>
                                    <select name="status" class="form-control" id="ProductStatus">
                                        <option value="1" <?php if($product->status == '1'): ?> selected <?php endif; ?>>Enable</option>
                                        <option value="0" <?php if($product->status == '0'): ?> selected <?php endif; ?>>Disable</option>
                                    </select>
                                    <?php echo $errors->first('status', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-sm-4 col-12">
                                    <label for="is Premium" class="control-label"><?php echo e('is Premium'); ?></label>
                                    <select name="is_premium" class="form-control" id="IsPremium">
                                        <option value="1" <?php if($product->is_premium == '1'): ?> selected <?php endif; ?>>Yes</option>
                                        <option value="0" <?php if($product->is_premium == '0'): ?> selected <?php endif; ?>>No</option>
                                    </select>
                                    <?php echo $errors->first('is_premium', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-sm-12 col-12">
                                    <label for="Product Description"
                                        class="control-label"><?php echo e('Product Description'); ?></label>
                                    <textarea class="form-control" name="product_description" rows="5"
                                        id="product_description"><?php echo e(isset($product->product_description) ? $product->product_description : ''); ?></textarea>
                                    <?php echo $errors->first('product_description', '<p class="help-block">:message</p>'); ?>

                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-sm-12 col-12 product_image_upload">
                                    <label for="Product Description" class="control-label"><?php echo e('File Upload'); ?></label>
                                    <input id="input-fa" name="product_image[]" accept="image/*" type="file"
                                        class="file-loading" accept="image/*" multiple>
                                </div>
                            </div>

                            <hr>

                            <div class="form-group">
                                <input class="btn btn-warning pull-left" type="reset" value="Reset">
                                <input class="btn btn-primary pull-right" type="submit" value="Update Product">
                            </div>

                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel.panel_design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\GITHUB\Ecommerce-Laravel\resources\views/admin/products/edit.blade.php ENDPATH**/ ?>