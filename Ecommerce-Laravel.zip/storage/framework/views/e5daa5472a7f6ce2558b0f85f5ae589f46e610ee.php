<?php $__env->startSection('content'); ?>
<header class="head">
    <div class="main-bar">
        <div class="row">
            <div class="col-6">
                <h4 class="m-t-5">
                    <i class="fa fa-home"></i>
                    Products
                </h4>
            </div>
        </div>
    </div>
</header>
<div class="outer">
    <div class="container">
        <div class="row">
            <div class="col-md-9 m-auto">
                <div class="card">
                    <div class="card-header">Create New Category</div>
                    <div class="card-body">
                        <a href="<?php echo e(url('/admin/product-category')); ?>" title="Back"><button
                                class="btn btn-warning btn-sm"><i class="fa fa-arrow-left" aria-hidden="true"></i>
                                Back</button></a>
                        <br />
                        <br />

                        <?php if($errors->any()): ?>
                        <ul class="alert alert-danger">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php endif; ?>

                        <form method="POST" action="<?php echo e(url('/admin/product-category')); ?>" accept-charset="UTF-8"
                            class="form-horizontal" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>


                            <div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                                <label for="name" class="control-label"><?php echo e('Name'); ?></label>
                                <input class="form-control" name="name" type="text" id="name"
                                    value="<?php echo e(isset($productcategory->name) ? $productcategory->name : ''); ?>">
                                <?php echo $errors->first('name', '<p class="help-block">:message</p>'); ?>

                            </div>
                            <div class="form-group <?php echo e($errors->has('description') ? 'has-error' : ''); ?>">
                                <label for="description" class="control-label"><?php echo e('Description'); ?></label>
                                <textarea class="form-control" rows="5" name="description" type="textarea"
                                    id="description"><?php echo e(isset($productcategory->description) ? $productcategory->description : ''); ?></textarea>
                                <?php echo $errors->first('description', '<p class="help-block">:message</p>'); ?>

                            </div>
                            <div class="form-group <?php echo e($errors->has('status') ? 'has-error' : ''); ?>">
                                <label for="status" class="control-label"><?php echo e('Status'); ?></label>
                                <select name="status" id="Status" class="form-control">
                                    <option value="1">Enable</option>
                                    <option value="0">Disable</option>
                                </select>
                                <?php echo $errors->first('status', '<p class="help-block">:message</p>'); ?>

                            </div>
                            <div class="form-group <?php echo e($errors->has('image') ? 'has-error' : ''); ?>">
                                <label for="image" class="control-label"><?php echo e('Image'); ?></label>
                                <input class="form-control" name="image" type="file" id="image"
                                    value="<?php echo e(isset($productcategory->image) ? $productcategory->image : ''); ?>">
                                <?php echo $errors->first('image', '<p class="help-block">:message</p>'); ?>

                            </div>

                            <div class="form-group">
                                <input class="btn btn-primary pull-right" type="submit" value="Add Category">
                            </div>

                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.panel.panel_design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\GITHUB\Ecommerce-Laravel\resources\views/admin/product-category/create.blade.php ENDPATH**/ ?>