<?php $__env->startSection('content'); ?>
<div id="particles-js"></div>
<div class="product-page-heading ">
    <div class="menu-destination-prehome">
        <ul class="list-unstyled text-center">
            <li>
                <div style="display: block;"><a>WELCOME</a></div>
            </li>
        </ul>
    </div>
</div>

<div class="container inquireform">
    <div class="col-lg-3 col-md-3 d-none d-md-block d-lg-block"></div>
    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
        <!-- Default form contact -->
        <form class=" p-4 form-horizontal register_valid m-b-20" id="register_valid" action="<?php echo e(route('register')); ?>"
            method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group row">
                <div class="col-sm-12">
                    <label class="col-form-label"><?php echo e(__('You are?')); ?></label>
                </div>
                <?php $__currentLoopData = Spatie\Permission\Models\Role::whereIn('name',
                array('Buyer','Supplier','Seller'))->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roles): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-3 col-12" id="UserOption">
                    <label class="custom-control custom-radio">
                        <input type="radio" id="If<?php echo e($roles->name); ?>" class="form-check-input" <?php if($roles->name ==
                        'User'): ?>
                        checked <?php endif; ?> name="roles"
                        value="<?php echo e($roles->name); ?>"
                        class="custom-control-input <?php if ($errors->has('roles')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('roles'); ?> is-invalid
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                        <span class="custom-control-indicator"></span>
                        <a class="custom-control-description"><?php echo e($roles->name); ?></a>
                    </label>
                    <?php if ($errors->has('roles')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('roles'); ?>
                    <span class="invalid-feedback text-white" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="form-group row d-none" id="IfSupplierCheck">
                <!-- Business name field -->
                <div class="col-sm-12">
                    <label for="Business Name" class="col-form-label"><?php echo e(__('Business Name *')); ?></label>
                    </span>
                    <input type="text" class="form-control <?php if ($errors->has('business_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('business_name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                        name="business_name" value="<?php echo e(old('business_name')); ?>" required id="business_name"
                        placeholder="Business Name">
                    <?php if ($errors->has('business_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('business_name'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <!-- /.Business name field -->
                <!-- Business Category field -->
                <div class="col-sm-12">
                    <label for="Category" class="col-form-label"><?php echo e(__('Category *')); ?></label>
                    <select name="supplier_category" id="supplier_category" class="form-control">
                        <option value=""> -- Select Category -- </option>
                        <?php $__currentLoopData = \App\SupplierCategory::where('status','1')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $suppCat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($suppCat->name); ?>"><?php echo e($suppCat->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if ($errors->has('supplier_category')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('supplier_category'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <!-- /.Business Category field -->
            </div>
            <div class="form-group row">
                <!-- Title field -->
                <div class="col-sm-6">
                    <label for="title" class="col-form-label"><?php echo e(__('Title *')); ?></label>
                    <div class="input-group">
                        <select type="text" class="form-control <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="title"
                            value="<?php echo e(old('title')); ?>" required id="title">
                            <option value="Mr.">Mr.</option>
                            <option value="Ms.">Ms.</option>
                            <option value="Mrs.">Mrs.</option>
                        </select>
                        <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                </div>
                <!-- /.Title field -->
                <!-- Username field -->
                <div class="col-sm-6">
                    <label for="username" class="col-form-label"><?php echo e(__('Username *')); ?></label>
                    <input type="text" class="form-control <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="username"
                        value="<?php echo e(old('username')); ?>" required id="username" placeholder="Username">
                    <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <!-- /.Username field -->
            </div>
            <div class="form-group row">
                <!-- First Name field -->
                <div class="col-sm-6">
                    <label for="first name" class="col-form-label"><?php echo e(__('First Name *')); ?></label>
                    <input type="text" class="form-control <?php if ($errors->has('first_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('first_name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="first_name"
                        value="<?php echo e(old('first_name')); ?>" required autocomplete="first_name" id="first_name"
                        placeholder="First Name">
                    <?php if ($errors->has('first_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('first_name'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <!-- /.First Name field -->
                <!-- Last Name field -->
                <div class="col-sm-6">
                    <label for="last name" class="col-form-label"><?php echo e(__('Last Name *')); ?></label>
                    <input type="text" class="form-control <?php if ($errors->has('last_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('last_name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="last_name"
                        value="<?php echo e(old('last_name')); ?>" required autocomplete="last_name" id="last_name"
                        placeholder="Last Name">
                    <?php if ($errors->has('last_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('last_name'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <!-- /.Last Name field -->
            </div>
            <div class="form-group row">
                <!-- Email Address field -->
                <div class="col-sm-6">
                    <label for="email" class="col-form-label"><?php echo e(__('Email Address *')); ?></label>
                    <input type="email" placeholder="Email Address" name="email" id="email"
                        class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('email')); ?>" required
                        autocomplete="email" />
                    <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <!-- /.Email Address field -->
                <!-- Phone number field -->
                <div class="col-sm-6">
                    <label for="phone" class="col-form-label"><?php echo e(__('Phone *')); ?></label>
                    <input type="tel" id="phone" placeholder="Phone Number" name="phone"
                        class="form-control <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('phone')); ?>" required
                        autocomplete="phone" />
                    <?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <!-- /.Phone number field -->
            </div>
            <div class="form-group row">
                <!-- Password field -->
                <div class="col-sm-6">
                    <label for="password" class="col-form-label text-sm-right"><?php echo e(__('Password *')); ?></label>
                    <input type="password" placeholder="Password" id="password" name="password"
                        class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" required
                        autocomplete="new-password" />
                    <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <!-- /.Password Field -->
                <!-- Confirm Password field -->
                <div class="col-sm-6">
                    <label for="password-confirm"
                        class="col-form-label text-md-right"><?php echo e(__('Confirm Password')); ?></label>
                    <input id="password-confirm" type="password" class="form-control" name="password_confirmation"
                        required autocomplete="new-password">
                    <?php if ($errors->has('confirmpassword')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('confirmpassword'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <!-- /.Confirm Password field -->
            </div>
            <div class="form-group row">
                <div class="col-sm-9">
                    <label class="custom-control custom-checkbox">
                        <input type="checkbox" class="form-check-input" name="terms" id="Terms" required>
                        <span class="custom-control-indicator"></span>
                        <span href="#" class="custom-control-description">I agree with the <a href="#"
                                style="text-decoration:underline;">Terms and
                                Conditions</a>.</span>
                    </label>
                </div>
            </div>
            <div class="form-group row">
                <div class="col-sm-12">
                    <button type="reset" class="btn btn-danger btn-lg pull-left">Reset</button>
                    <input type="submit" value="Register" class="btn btn-primary btn-lg pull-right" />
                </div>
            </div>
        </form>
    </div>
</div>
<div class="col-lg-3 col-md-3 d-none d-md-block d-lg-block"></div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front.front_design', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\GITHUB\Ecommerce-Laravel\resources\views/auth/register.blade.php ENDPATH**/ ?>