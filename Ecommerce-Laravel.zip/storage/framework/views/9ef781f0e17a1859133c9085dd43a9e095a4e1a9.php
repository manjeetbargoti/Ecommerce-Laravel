<html>

<head>
    <title>Supplier Query | VVV Luxury</title>
</head>

<body>
    <table>
        <tr>
            <td>Dear <?php echo e($supplier_name); ?></td>
        </tr>
        <tr>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>One user query about you on VVV Luxury.</td>
        </tr>
        <tr>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>Name:</td>
            <td><?php echo e($name); ?></td>
        </tr>
        <tr>
            <td>Email:</td>
            <td><?php echo e($email); ?></td>
        </tr>
        <tr>
            <td>Phone:</td>
            <td><?php echo e($phone); ?></td>
        </tr>
        <tr>
            <td>Location:</td>
            <td><?php echo e($location); ?></td>
        </tr>
        <tr>
            <td>Message:</td>
            <td><?php echo e($query_message); ?></td>
        </tr>
        <tr>
            <td>&nbsp;</td>
        </tr>
        <tr>
            <td>Thanks & Regards,</td>
        </tr>
        <tr>
            <td>VVV Luxury</td>
        </tr>
    </table>
</body>

</html><?php /**PATH D:\GITHUB\Ecommerce-Laravel\resources\views/emails/supplier_query.blade.php ENDPATH**/ ?>