<html>
    <head>
        <title>Product Link | VVV Luxury</title>
    </head>
    <body>
        <table>
            <tr><td>Dear <?php echo e($name); ?></td></tr>
            <tr><td>&nbsp;</td></tr>
            <tr><td>Please click on below link to check product:</td></tr>
            <tr><td>&nbsp;</td></tr>
            <tr><td><a href="<?php echo e(url('/product/'.$id.'/'.$token)); ?>">PRODUCT URL</a></td></tr>
            <tr><td>&nbsp;</td></tr>
            <tr><td>Thanks & Regards,</td></tr>
            <tr><td>VVV Luxury</td></tr>
        </table>
    </body>
</html><?php /**PATH D:\GITHUB\Ecommerce-Laravel\resources\views/emails/product_url.blade.php ENDPATH**/ ?>