<!-- <div id="particles-js"></div> -->
<div class=""
    style="background-image: url('<?php echo e(url('images/product-category/large/'.$pcategory->image)); ?>');background-size:cover;">
    <div class="product-page-heading ">
        <div class="menu-destination-prehome">
            <ul class="list-unstyled text-center product-supplier">
                <li class="active">
                    <div style="display: block;"><a class="" href="<?php echo e(url('/product/categories')); ?>">PRODUCTS</a></div>
                </li>
                <li class="">
                    <div style="display: block;"><a class="" href="<?php echo e(url('/supplier/categories')); ?>">SUPPLIERS</a>
                    </div>
                </li>
            </ul>
        </div>
    </div>

    <div class="product-page-content">
        <div class="menu-destination-prehome">
            <ul class="list-unstyled text-center">
                <?php $__currentLoopData = $productcategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pcat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="">
                    <span style="display: block;"><a class=""
                            href="<?php echo e(url('/category/'.$pcat->name.'/products/')); ?>"><?php echo e($pcat->name); ?></a></span>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <div class="menu-destination-prehome" style="padding-top: 7em;">
            <ul class="list-unstyled text-center">
                <li class="">
                    <span style="display: block;"><a class="" href="<?php echo e(url('/vvv-lux/products/')); ?>"
                            style="font-size: 3em !important;">VVV LUXURY</a></span>
                </li>
            </ul>
        </div>
        <div class="space2"></div>
    </div>
</div><?php /**PATH D:\GITHUB\Ecommerce-Laravel\resources\views/front/product/partials/category_list.blade.php ENDPATH**/ ?>